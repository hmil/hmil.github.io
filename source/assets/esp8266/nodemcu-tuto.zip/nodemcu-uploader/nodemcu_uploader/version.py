# -*- coding: utf-8 -*-
# Copyright (C) 2015-2016 Peter Magnusson <peter@birchroad.net>
"""just keeper of current version"""

#TODO: remember to update tests when version changes
__version__ = '0.4.3'
