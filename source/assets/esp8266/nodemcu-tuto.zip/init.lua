-- init.lua
-- Loads the WIFI_NETWORK and WIFI_PASSWORD secret variables
dofile('env.lua')

-- Connect to the wifi network
wifi.setmode(wifi.STATION)
wifi.sta.config({ssid = WIFI_SSID, pwd = WIFI_PASSWORD})


-- index of the gpio connected to the onboard LED
LED_PIN=4

gpio.mode(LED_PIN, gpio.OUTPUT)
gpio.write(LED_PIN, 1)

-- This will print IP informations upon successful connection
wifi.eventmon.register(wifi.eventmon.STA_GOT_IP, function(T)
    print('\n\tSTA - GOT IP'..'\n\tStation IP: '..T.IP..'\n\tSubnet mask: '..
    T.netmask..'\n\tGateway IP: '..T.gateway)
end)

-- Create a TCP server
sv = net.createServer(net.TCP, 30)

headers = 'Content-Type: text/html; charset=UTF-8\r\n'

-- Configure the server to print the data it gets and respond
-- with a greeting message
if sv then
  sv:listen(80, function(conn)
    conn:on('receive', receiver)
  end)
end

function receiver(sck, data)
    print(data)
    firstLine = string.sub(data, 0, string.find(data, '\n'))

    message = ''
    if string.match(firstLine, 'GET /on ') then
        message = '<pre>turned on!</pre>'
        gpio.write(LED_PIN, 0) -- Note that the led shows the inverse of the logic state of the gpio
    elseif string.match(firstLine, 'GET /off ') then
        message = '<pre>turned off!</pre>'
        gpio.write(LED_PIN, 1)
    end

    if string.match(firstLine, 'GET /') or message ~= '' then
        sck:send('HTTP/1.1 200 OK\r\n'.. headers .. '\r\n'..
                '<h1>Hello from ESP8266!</h1>' ..
                message ..
                '<a href="/on">Turn light on</a> - <a href="/off">Turn light off</a>')
    else
        sck:send('HTTP/1.1 404 NOT FOUND\r\n'.. headers .. '\r\n'..
                'Not found.<br/><a href="/">Go back home</a>')  
    end
    sck:on('sent', function () sck:close() end)
end
